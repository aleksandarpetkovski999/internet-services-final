﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
   public class Club
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [MaxLength(200)]
        public string Name { get; set; }
        [Required]
        [MaxLength(200)]
        public string Owner { get; set; }
        [Required]
        [MaxLength(200)]
        public string City { get; set; }
        [Required]
        [MaxLength(200)]
        public string Country { get; set; }
    }
}
