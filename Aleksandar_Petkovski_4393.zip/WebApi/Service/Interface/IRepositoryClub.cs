﻿using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service.Interface
{
    public interface IRepositoryClub
    {
        Task<List<Club>> GetAllClub();
        Task<Club> GetByID(int id);
        Task<Club> PostClub(Club Club); 
        Task PutClub(Club Club);
        Task<bool> DeleteClub(int id);
    }
}
