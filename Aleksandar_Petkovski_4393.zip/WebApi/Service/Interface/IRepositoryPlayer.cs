﻿using Data;
using Microsoft.EntityFrameworkCore;
using Models;
using Service.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service.Interface
{
    public interface IRepositoryPlayer
    {
        Task<List<Player>> GetAllPlayer();
        Task<Player> GetByID(int id);
        Task<Player> PostPlayer(Player student);
        Task PutPlayer(Player player);
        Task<bool> DeletePlayer(int id);
    }
   
}
