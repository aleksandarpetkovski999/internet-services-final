﻿using Data;
using Microsoft.EntityFrameworkCore;
using Models;
using Service.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service.Services
{
    public class RepositoryClub : IRepositoryClub
    {
        private readonly ApplicationDbContext context;
        public RepositoryClub(ApplicationDbContext _context)
        {
            this.context = _context; 
        }
        public async Task<List<Club>> GetAllClub()
        {
            return await context.Clubs.ToListAsync();
        }

        public async Task<Club> GetByID(int id)
        {
            return await context.Clubs.FirstOrDefaultAsync(x => x.Id == id);
        }
        public Task PutClub(Club Club)
        {
            context.Entry(Club).State = EntityState.Modified;
            return context.SaveChangesAsync();
        }
        public async Task<Club> PostClub(Club Club)
        {
            context.Clubs.Add(Club);
            await context.SaveChangesAsync();
            return Club;
        }
        public async Task<bool> DeleteClub(int id)
        {
            var club = await context.Clubs.FindAsync(id);
            context.Clubs.Remove(club);
            await context.SaveChangesAsync();
            return true;
        }

       

        

       

        
    }
}
