﻿using Data;
using Microsoft.EntityFrameworkCore;
using Models;
using Service.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Service.Services
{
    public class RepositoryPlayer : IRepositoryPlayer
    {
        private readonly ApplicationDbContext context;
        public RepositoryPlayer(ApplicationDbContext _context)
        {
            this.context = _context;
        }
        public async Task<List<Player>> GetAllPlayer()
        {
            return await context.Players.Include(x => x.Club).ToListAsync();
        }

        public async Task<Player> GetByID(int id)
        {
            return await context.Players.Include(x => x.Club).FirstOrDefaultAsync(x => x.Id == id);
        }

        public Task PutPlayer(Player player)
        {
            context.Entry(player).State = EntityState.Modified;
            return context.SaveChangesAsync();
        }

        public async Task<Player> PostPlayer(Player Player)
        {
            context.Players.Add(Player);
            await context.SaveChangesAsync();
            return Player;
        }

        public async Task<bool> DeletePlayer(int id)
        {
            var Player = await context.Players.FindAsync(id);
            context.Players.Remove(Player);
            await context.SaveChangesAsync();
            return true;
        }
    }
}
