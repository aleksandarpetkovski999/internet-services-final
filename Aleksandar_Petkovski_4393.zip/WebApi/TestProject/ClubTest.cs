using Data;
using Microsoft.EntityFrameworkCore;
using Models;
using Moq;
using NUnit.Framework;
using Service.Interface;
using Service.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using WebApi.Controllers;

namespace TestProject
{
    public class ClubTest
    {

        private Mock<IRepositoryClub> _clubRepository;
        private List<Club> ClubList;
        [SetUp]
        public void Setup()
        {
            _clubRepository = new Mock<IRepositoryClub>();
            ClubList = new List<Club>();
            ClubList.Add(new Club() { Id = 1, Name = "Wahab" ,Owner="Asif",City="Melaka", Country="USA"});
            ClubList.Add(new Club() { Id = 2, Name = "Atif", Owner = "Akhtar", City = "KL", Country = "England" });
        }

        [Test]
        public async Task GetAllClub()
        {
            _clubRepository.Setup(m => m.GetAllClub()).ReturnsAsync(ClubList);
            IList<Club> clubs = await _clubRepository.Object.GetAllClub();
            Assert.IsTrue(clubs.Count >= 1);
        }

        [Test]
        public async Task AddClub()
        {
            _clubRepository.Setup(m => m.GetAllClub()).ReturnsAsync(ClubList);

            Club newClub = new Club() { Id = 1, Name = "Steve", Owner = "Tay", City = "Tan", Country = "USA" };
            ClubList.Add(newClub);
            _clubRepository.Setup(r => r.PostClub(newClub));
            await _clubRepository.Object.PostClub(newClub);
            IList<Club> people =await _clubRepository.Object.GetAllClub();
            Assert.IsTrue(people.Where(x=>x.Name== "Steve").Select(x=>x.Name).FirstOrDefault() == "Steve");
        }

        [Test]
        public void ClubGetById()
        {
            // Arrange.
            int ClubId = 1;
            var Club = ClubList.Where(x=>x.Id== ClubId).SingleOrDefault();
            Assert.IsNotNull(Club);
            Assert.AreEqual(Club.Id, ClubId);
        }
    }
}