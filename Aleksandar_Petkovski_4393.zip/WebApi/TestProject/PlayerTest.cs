﻿using Data;
using Microsoft.EntityFrameworkCore;
using Models;
using Moq;
using NUnit.Framework;
using Service.Interface;
using Service.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using WebApi.Controllers;

namespace TestProject
{
    public class PlayerTest
    {
        private Mock<IRepositoryPlayer> _playerRepository;
        private List<Player> PlayerList;
        [SetUp]
        public void Setup()
        {
            _playerRepository = new Mock<IRepositoryPlayer>();
            PlayerList = new List<Player>();
            PlayerList.Add(new Player() { Id = 1, FirstName = "Wahab", LastName = "Asif", DOB = System.DateTime.Now.AddDays(-10).AddYears(-30), SigningDate = System.DateTime.Now , TotalGoals=3 , ClubId =1});
            PlayerList.Add(new Player() { Id = 2, FirstName = "Atif", LastName = "Akhtar", DOB = System.DateTime.Now.AddDays(-20).AddYears(-50), SigningDate = System.DateTime.Now, TotalGoals=5, ClubId =2});
        }

        [Test]
        public async Task GetAllPlayer()
        {
            _playerRepository.Setup(m => m.GetAllPlayer()).ReturnsAsync(PlayerList);
            IList<Player> clubs = await _playerRepository.Object.GetAllPlayer();
            Assert.IsTrue(clubs.Count >= 1);
        }

        [Test]
        public async Task AddPlayer()
        {
            _playerRepository.Setup(m => m.GetAllPlayer()).ReturnsAsync(PlayerList);

            Player newPlayer = new Player() { Id = 1, FirstName = "Steve", LastName = "Tay", DOB = System.DateTime.Now.AddDays(-10).AddYears(-30), SigningDate = System.DateTime.Now, TotalGoals = 3, ClubId = 3 };
            PlayerList.Add(newPlayer);
            _playerRepository.Setup(r => r.PostPlayer(newPlayer));
            await _playerRepository.Object.PostPlayer(newPlayer);
            IList<Player> people = await _playerRepository.Object.GetAllPlayer();
            Assert.IsTrue(people.Where(x => x.FirstName == "Steve").Select(x => x.FirstName).FirstOrDefault() == "Steve");
        }

        [Test]
        public void PlayerGetById()
        {
            // Arrange.
            int PlayerId = 1;
            var Player = PlayerList.Where(x => x.Id == PlayerId).SingleOrDefault();
            Assert.IsNotNull(Player);
            Assert.AreEqual(Player.Id, PlayerId);
        }
    }
}
