﻿using Microsoft.AspNetCore.Mvc;
using Service.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApi.DTO;

namespace WebApi.Controllers
{
    public class ClubController : Controller
    {
        private readonly IRepositoryClub  ClubRepo;
        public ClubController(IRepositoryClub _clubRepo)
        {
            this.ClubRepo = _clubRepo;
        }

        [HttpGet("GetAllClub")]
        public async Task<List<ClubDto>> Get()
        {
            var Club= await ClubRepo.GetAllClub();
            List<ClubDto> Clubs = new List<ClubDto>();
            foreach (var n in Club )
            {
                var c = new ClubDto
                {
                    Id = n.Id,
                    Name = n.Name,
                    Owner = n.Owner,
                    City = n.City,
                    Country = n.Country,
                };
                Clubs.Add(c);
            }

            return Clubs;
        }


        [HttpGet("{id}")]
        public async Task<ActionResult<ClubDto>> GetById(int id)
        {
            var c = await ClubRepo.GetByID(id);
            if (c == null)
            {
                return NotFound();
            }
            var club = new ClubDto
            {
                Id = c.Id,
                Name = c.Name,
                Owner = c.Owner,
                City = c.City,
                Country = c.Country,
               
            };
            return club;
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutPlayer(int id, ClubDto club)
        {
            if (id != club.Id)
            {
                return BadRequest();
            }
            var clubModel = new Models.Club
            {
                Id = club.Id,
                Name = club.Name,
                Owner = club.Owner,
                City = club.City,
                Country = club.Country,
            };

            await ClubRepo.PutClub(clubModel);
            return NoContent();
        }


        [HttpPost("PostClub")]
        public async Task<ActionResult<ClubDto>> PostStudent(ClubDto club)
        {
            var clubModel = new Models.Club
            {
                Id = club.Id,
                Name = club.Name,
                Owner = club.Owner,
                City = club.City,
                Country = club.Country,
            };
            var GetClub = await ClubRepo.PostClub(clubModel);

            return CreatedAtAction("GetById", new { id = GetClub.Id }, GetClub);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteStudent(int id)
        {
            var student = await ClubRepo.DeleteClub(id);
            if (student)
            {
                return NoContent();
            }
            return NoContent();
        }
    }
}
