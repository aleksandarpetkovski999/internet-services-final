﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Service.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApi.DTO;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PlayerController : ControllerBase
    {
        private readonly IRepositoryPlayer playerRepo;
        public PlayerController(IRepositoryPlayer _playerRepo)
        {
            this.playerRepo = _playerRepo;
        }

        [HttpGet]
        public async Task<List<Player>> Get()
        {
            var player = await playerRepo.GetAllPlayer();
            List<Player> players = new List<Player>();
            foreach(var n in player) 
            {
                var p = new DTO.Player
                {
                    Id = n.Id,
                    FirstName=n.FirstName,
                    LastName=n.LastName,
                    SigningDate=n.SigningDate,
                    TotalGoals=n.TotalGoals,
                    DOB=n.DOB,
                    Club=n.Club,
                };
                players.Add(p);
            }
           
            return players;
        }


        [HttpGet("{id}")]
        public async Task<ActionResult<Player>> GetById(int id)
        {
            var p = await playerRepo.GetByID(id);
            if (p == null)
            {
                return NotFound();
            }
            var player = new Player {
                Id = p.Id,
                FirstName = p.FirstName,
                LastName = p.LastName,
                SigningDate = p.SigningDate,
                TotalGoals = p.TotalGoals,
                DOB = p.DOB,
                Club = p.Club,
            };
            return player;
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutPlayer(int id, Player player)
        {
            if (id != player.Id)
            {
                return BadRequest();
            }
            var PlayerModel = new Models.Player {
               Id=player.Id,
               FirstName= player.FirstName,
                LastName = player.LastName,
                SigningDate = player.SigningDate,
                TotalGoals = player.TotalGoals,
                DOB = player.DOB,
                Club = player.Club,
                ClubId=player.ClubId,
            };

            await playerRepo.PutPlayer(PlayerModel);
            return NoContent();
        }


        [HttpPost]
        public async Task<ActionResult<Player>> PostStudent(Player player)
        {
            var PlayerModel = new Models.Player
            {
                Id = player.Id,
                FirstName = player.FirstName,
                LastName = player.LastName,
                SigningDate = player.SigningDate,
                TotalGoals = player.TotalGoals,
                DOB = player.DOB,
                ClubId = player.ClubId,
            };
            var GetPlayer = await playerRepo.PostPlayer(PlayerModel);

            return CreatedAtAction("GetById", new { id = GetPlayer.Id }, GetPlayer);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteStudent(int id)
        {
            var student = await playerRepo.DeletePlayer(id);
            if (student)
            {
                return NoContent();
            }
            return NoContent();
        }
    }
}
